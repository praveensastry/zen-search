import * as path from "path";

export const config = {
  dataDir: path.join(__dirname, "..", "data"),
};
